<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">unpadleft</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNClN0cmlu
ZyBpblN0cmluZyA9IElEYXRhVXRpbC5nZXRTdHJpbmcoIHBpcGVsaW5lQ3Vyc29yLCAiaW5TdHJp
bmciICk7DQpTdHJpbmcgdW5wYWRTdHJpbmcgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGlu
ZUN1cnNvciwgInVucGFkU3RyaW5nIik7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQogDQpT
dHJpbmcgdmFsdWUgPSB1blBhZExlZnQoaW5TdHJpbmcsIHVucGFkU3RyaW5nLmNoYXJBdCgwKSk7
DQoNCi8vIHBpcGVsaW5lDQpJRGF0YUN1cnNvciBwaXBlbGluZUN1cnNvcl8xID0gcGlwZWxpbmUu
Z2V0Q3Vyc29yKCk7DQpJRGF0YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvcl8xLCAidmFsdWUiLCB2
YWx1ZSApOw0KcGlwZWxpbmVDdXJzb3JfMS5kZXN0cm95KCk7</value>
</Values>
